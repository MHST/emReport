<?php

/**
 * @Project emReport module
 * @Author K55CA UET (DuNT;LocBH;ThangLD)
 * @copyright 2012
 * @createdate 11/06/2012 8:34
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = "VINADES.,JSC (contact@vinades.vn)";
$lang_translator['createdate'] = "01/07/2012, 09:38";
$lang_translator['copyright'] = "@Copyright (C) 2012 VINADES.,JSC. All rights reserved";
$lang_translator['info'] = "";
$lang_translator['langtype'] = "lang_module";

$lang_module['main'] = "Trang chính";
$lang_module['detail'] = "Xem chi tiết";
$lang_module['search'] = "Tìm kiếm";
$lang_module['loginalert'] = "Đăng nhập để bắt đầu sử dụng !";
$lang_module['search_lable'] = "Tìm kiếm bệnh nhân";

?>