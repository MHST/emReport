<?php

/**
 * @Project emReport module
 * @Author K55CA UET (DuNT;LocBH;ThangLD)
 * @copyright 2012
 * @createdate 11/06/2012 8:34
 */

if (!defined('NV_SYSTEM')) die('Stop!!!');

$allow_func = array('main', 'view', 'create', 'search');
 
define('NV_IS_MOD_EMREPORT', true); 

?>